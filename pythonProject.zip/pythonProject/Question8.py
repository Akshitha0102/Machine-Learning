radius=10
area=3.14*radius**2
#using string formatting method(format) to insert numerical values between string
x="The area of the circle with radius {0} is {1} meters square".format(radius,area)
print(x)