text="I am a teacher and I love to inspire and teach people"
#split the string and convert into set
unique_words=set(text.split())
print(unique_words)
# split() method divides the words individually in the sentence
b=set(unique_words)
print(b)
print(len(b))
