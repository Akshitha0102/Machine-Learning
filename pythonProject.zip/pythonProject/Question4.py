it_companies={'Facebook', 'Google', 'Microsoft', 'Apple', 'IBM', 'Oracle', 'Amazon'}
A={19,22,24,20,25,26}
B={19,22,20,25,26,24,28,27}
age=[22,19,24,25,26,24,25,24]
#length of the set it_companies using length method
length_of_it_companies = len(it_companies)
print("\n Length of it companies : ", length_of_it_companies)
it_companies.add("Twitter")
print("\n After adding Twitter to the IT companies : ", it_companies)
#add multiple it companies to the set it_companies
it_companies.update(["Capgemini", "Albatroz", "Excers"])
print("\n After adding multiple companies  to the IT companies : ", it_companies)
#remove one of the companies from set it_companies
it_companies.remove('Excers')
print("\n Removing TCS from the set : ", it_companies)
#what is the difference between remove and discard

#Remove(): removes the element from the set. A KeyError is raised if element is not present in the set.
#Discard(): This function accepts element as an argument and if that exists in the set then it deletes that. If the given element does not exist in the set, then discard() function does nothing.
#unlike remove() function discard() function throws no error.

#join A and B
join=A.union(B)
print("\n Joining A and B : ", join)
#A intersection B
intersection=A.intersection(B)
print("The intersection of A and B : ", intersection)
#Is A subset of B
print("Is A subset of B : ", A.issubset(B))
#Are A and B disjoint Sets
print("Are A and B are disjoint sets : ", A.isdisjoint(B))
#join a with b and b with a
join_a = A.union(B)
join_b = B.union(A)
print("Joining A with B : ", join_a)
print("Joining B with A : ", join_b)

#what is the symmetric difference between a and b
symmetric_difference = A.symmetric_difference(B)
print("The symmetric difference between A and B is : ", symmetric_difference)
#delete the sets completely
A.clear()
B.clear()
#convert ages to set and compare the length of the list to the set
age_List = set(age)
print("Length of age in set format : ", len(age_List))
print("Length of age in List format: :", len(age))


