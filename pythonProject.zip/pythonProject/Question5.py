radius_of_circle=30

#area of a circle
_area_of_circle_=3.14*30*30
print("The area of circle is ", _area_of_circle_)
#circumference of a circle
_circum_of_circle_=2*3.14*30
print("The circumference of  circle is ", _circum_of_circle_)
#taking radius as user input and calculate the area
radius=float(input("Enter the radius of circle: "))
area_of_circle = 3.14*radius*radius
print("The area of circle is ", area_of_circle)
