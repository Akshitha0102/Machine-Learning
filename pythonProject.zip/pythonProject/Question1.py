age=[19,22,19,24,20,25,26,24,25,24]
#Sorting the list
age.sort()
print("The sorted age is: ", age)
#Minimum and maximum of age list
minimum = min(age)
maximum = max(age)
print("The minimum age is ", minimum)
print("The maximum age is ", maximum)
#appending minimum and maximum age to the list
age.append(minimum)
age.append(maximum)
print("Age after appending: ", age)
#median of age
age_length=len(age)
median=int(age_length/2)
print("Median is : ", age[median])
#average of age
total_age = sum(age)
average = total_age/age_length
print("Average is : ", average)
#range
range = maximum-minimum
print("Range is : ", range)



