#create a tuple names of your sisters and brothers
brothers=("Vivek", "Nikhil", "Bharath")
sisters=("Pandu", "Lahari", "Raga")
#join brothers and sisters and assign to sibilings
siblings = brothers + sisters
print(siblings)
#how many sibilinga do you have
siblings_length = len(siblings)
print(siblings_length)
#modify tuple and add the names of your father and mother and assign to family members
#converting set to list
sibling = list(siblings)
#appending mother and father names to the list
sibling.append("Vijay")
sibling.append("Latha")
#converting sibiling to set and assiging the set to family_members
family_members=set(sibling)
print(family_members)
