#creating an empty dog dictionary
dog={}
#adding name, color, legs,breed, age to dog dictionary
dog["name"]="Snoopy"
dog["color"]="Black"
dog["legs"]=4
dog["breed"]="German_Sheperd"
dog["age"]=5
#create student dictionary
student={"first_name":"Akshitha_Reddy", "last_name":"Sanugommula", "gender":"Female", "age":23, "marital_status":"Single",
         "skills":["Python","Java","SQL"], "country":"USA", "city":"Overland_Park", "address":"Hardy_Street"}
#length of dictionary
student_length=len(student)
print("The length of student dictionary is : ", student_length)
#get the value of the skills and check the data type ,it should be list
x=[]
x = student["skills"]
print("The skills are : ", x)
print("Type of skills is : ", type(x))
#modifying the skills by adding one or two skills
student["skills"].append("C#")
print("The updated skills :",student["skills"])
#To get the dictionary keys as a list
student_keys = list(student.keys())
dog_keys = list(dog.keys())
print("The keys of student dictionary are : ", student_keys)
print("The keys of dog dictionary are : ", dog_keys)
#To get the dictionary values a list
student_values=list(student.values())
dog_values=list(dog.values())
print("The values of student dictionary are : ", student_values)
print("The values of dog dictionary are : " , dog_values)

