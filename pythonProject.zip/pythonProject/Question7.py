#using tab escape sequence to print the words
print("Name \t", "    Age\t", "Country \t", "City \t")
print("Asabeneh \t", "250 \t", "Finland \t", "Helsinki")
